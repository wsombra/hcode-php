<?php

setlocale(LC_ALL, "pt-BR", "pt_BR.utf-8", "portuguese");

echo ucwords(strftime("%A %B"));

?>