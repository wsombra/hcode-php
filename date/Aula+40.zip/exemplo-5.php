<?php

$dt = new DateTime();

echo $dt->format("d/m/Y H:i:s");

?>