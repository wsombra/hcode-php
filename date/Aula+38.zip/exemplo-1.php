<?php

echo date("d/m/Y H:i:s", 1882758040);

echo "<br>";

echo time();

?>