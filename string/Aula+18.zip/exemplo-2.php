<?php

$nome = "Joao Rangel";

$nome = strtoupper($nome);

echo $nome;

$nome = strtolower($nome);

echo "<br>";

echo $nome;

echo "<br>";

echo ucfirst($nome);

echo "<br>";

echo ucwords($nome);

?>