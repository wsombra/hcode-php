<?php

$nome = "Hcode";

$nome2 = 'Treinamentos';

//var_dump($nome, $nome2);

echo "ABC $nome";

?>