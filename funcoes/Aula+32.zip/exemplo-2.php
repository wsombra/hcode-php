<?php

function salario(){

    return 500.00;
    
};

echo "José recebeu 2 salários: ".(salario()*2);

?>