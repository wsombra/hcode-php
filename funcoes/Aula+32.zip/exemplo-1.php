<?php

function ola(){

    return "Olá Mundo<br>";
    
};

echo ola();
$frase = ola();

echo strlen($frase);

?>